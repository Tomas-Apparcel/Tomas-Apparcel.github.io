---
title: 'Taller de Producto 2021'
date: 2018-11-28T15:14:39+10:00
weight: 1
---

## Documentación del Taller de Producto

Este template será utilizado para generar la documentación de los trabajos realizados en el Taller de Producto 2021.